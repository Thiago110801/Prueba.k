<?php
include_once 'conexion.php';
session_start();
?>


<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Cafeteria
        
    </title>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

    <!-- Required meta tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/css/bootstrap.min.css">

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/js/bootstrap.min.js"></script>

    <!-- Datatables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/v/bs4-4.1.1/dt-1.10.18/datatables.min.css">
    <script src="https://cdn.datatables.net/v/bs4-4.1.1/dt-1.10.18/datatables.min.js"></script>

    <!-- Buttons -->
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.2/css/buttons.dataTables.min.css">
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.53/build/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
</head>

<style>
    thead {
        background: linear-gradient(to right, #00dbde, #3AC971);
        color: rgb(13, 87, 224);
    }

    #mydatatable tfoot input {
        width: 100% !important;
    }

    #mydatatable tfoot {
        display: table-header-group !important;
    }
</style>

<body class="home-template">
    <!-- menu -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="vender.php">Inicio</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDarkDropdown" aria-controls="navbarNavDarkDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            CONSULTA
                        </a>
                        <ul class="dropdown-menu dropdown-menu-dark">
                            <li><a class="dropdown-item" href="consulta.php">Producto con mas Stock</a></li>
                            <li><a class="dropdown-item" href="consulta1.php">Producto mas Vendidos</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    </br>
    <div class="table-responsive" id="mydatatable-container ">
        <h1 class="text-center">Modulo de Consulta Producto mas Vendidos </h1>
        </br>
        <div class="container text-center">
            <div class="row">
                <div class="col-lg-12">

                    </br>
                    <table class="records_list table table-striped table-bordered table-hover" id="mydatatable" class="display nowrap" style="width:100%">
                    <thead class="text-center">
                            <tr>
                                <td>ID</td>
                                <td>Producto</td>
                                <td>Referencia</td>
                                <td>Precio</td>
                                <td>Peso</td>
                                <td>Categoria</td>
                                <td>Stock</td>
                                <td>Fecha</td>
                            </tr>
                        </thead>

                        <tfoot>
                            <tr>
                                <th>Filter..</th>
                                <th>Filter..</th>
                                <th>Filter..</th>
                                <th>Filter..</th>
                                <th>Filter..</th>
                                <th>Filter..</th>
                                <th>Filter..</th>
                                <th>Filter..</th>
                            </tr>
                        </tfoot>

                        <tbody class="text-center">
                            <?php foreach ($mydatatable as $mydatatable) : ?>

                                <tr>
                                    <td><?php echo $mydatatable->ID; ?></td>
                                    <td><?php echo $mydatatable->nombreproducto; ?></td>
                                    <td><?php echo $mydatatable->referencia; ?></td>
                                    <td><?php echo $mydatatable->precio; ?></td>
                                    <td><?php echo $mydatatable->peso; ?></td>
                                    <td><?php echo $mydatatable->categoria; ?></td>
                                    <td><?php echo $mydatatable->stock; ?></td>
                                    <td><?php echo $mydatatable->fechacreacion; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>


                    </table>
                </div>
            </div>
        </div>
        <script type="text/javascript">
            $(document).ready(function() {
                $('#mydatatable tfoot th').each(function() {
                    var title = $(this).text();
                    $(this).html('<input type="text" placeholder="Filtrar.." />');
                });


                var table = $('#mydatatable').DataTable({
                    "dom": 'B<"float-left"i><"float-right"f>t<"float-left"l><"float-right"p><"clearfix">',
                    "responsive": false,
                    "language": {
                        "url": "https://cdn.datatables.net/plug-ins/1.10.19/i18n/Spanish.json"
                    },
                    "order": [
                        [0, "desc"]
                    ],
                    "initComplete": function() {
                        this.api().columns().every(function() {
                            var that = this;

                            $('input', this.footer()).on('keyup change', function() {
                                if (that.search() !== this.value) {
                                    that
                                        .search(this.value)
                                        .draw();
                                }
                            });
                        })
                    },
                    "buttons": ['csv', 'excel', 'pdf', 'print']
                });
            });
        </script>


</body>

</html>