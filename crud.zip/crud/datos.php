<?php
header('Content-Type: application/json');

require("conexion.php");

$conexion = retornarConexion();

switch ($_GET['accion']) {
    case 'listar':
        $datos = mysqli_query($conexion, "select ID, nombreproducto, referencia, precio, peso, categoria, stock, fechacreacion from producto");
        $resultado = mysqli_fetch_all($datos, MYSQLI_ASSOC);
        echo json_encode($resultado);
        break;

    case 'agregar':
        $respuesta = mysqli_query($conexion, "insert into producto(ID, nombreproducto, referencia, precio, peso, categoria, stock, fechacreacion) values ('$_POST[ID]','$_POST[nombreproducto]','$_POST[referencia]','$_POST[precio]','$_POST[peso]','$_POST[categoria]','$_POST[stock]','$_POST[fechacreacion]')");
        echo json_encode($respuesta);
        break;

    case 'borrar':
        $respuesta = mysqli_query($conexion, "delete from producto where ID=$_GET[ID]");
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $datos = mysqli_query($conexion, "select ID, nombreproducto, referencia, precio, peso, categoria, stock, fechacreacion from producto where ID=$_GET[ID]");
        $resultado = mysqli_fetch_all($datos, MYSQLI_ASSOC);
        echo json_encode($resultado);
        break;

    case 'modificar':
        $respuesta = mysqli_query($conexion, "update producto set
                                                  ID='$_POST[ID]',
                                                  nombreproducto=$_POST[nombreproducto]
                                                  referencia=$_POST[referencia]
                                                  precio=$_POST[precio]
                                                  peso=$_POST[peso]
                                                  categoria=$_POST[categoria]
                                                  stock=$_POST[stock]
                                                  fechacreacion=$_POST[fechacreacion]
                                               where ID=$_GET[ID]");
        echo json_encode($respuesta);
        break;
}
