<?php

function retornarConexion() {
    $server="localhost";
    $usuario="root";
    $clave="";
    $base="cafeteria";
    $conexion = new mysqli($server,$usuario,$clave,$base) or die("problemas") ;
    mysqli_set_charset($conexion,'utf8'); 
    return $conexion;
}
?>